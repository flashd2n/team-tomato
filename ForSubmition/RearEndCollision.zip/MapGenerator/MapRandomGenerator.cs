using System;
using System.Collections.Generic;
using System.Text;

namespace RearEndCollision
{
	public class MapRandomGenerator : MapGenerator
	{
        // TODO: The randomnes factor can be implemanted by simple Prim algo using: random number of MST node count
        
		public override char[,] GenerateMap()
		{
			throw new NotImplementedException();
		}
	}
}
