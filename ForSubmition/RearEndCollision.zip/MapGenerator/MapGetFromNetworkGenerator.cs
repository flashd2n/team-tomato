using System;
using System.Collections.Generic;
using System.Text;

namespace RearEndCollision
{
	public class MapGetFromNetworkGenerator : MapGenerator
	{
        // TODO: The Host is generating the map. The others are recieving it ot self-generate it from "a send pattern"
		public override char[,] GenerateMap()
		{
			throw new NotImplementedException();
		}
	}
}
