using System;
using System.Collections.Generic;
using System.Text;

namespace RearEndCollision
{
	public struct Command
	{
        public ulong GameTick;


        public int PlayerId;


        public CommandType PlayerCommand;
	}
}
