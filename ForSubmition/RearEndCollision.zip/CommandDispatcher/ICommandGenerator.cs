using System;
using System.Collections.Generic;
using System.Text;

namespace RearEndCollision
{
	public interface ICommandGenerator
	{
		Command GetCommand();
	}
}
