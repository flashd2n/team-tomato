using System;
using System.Collections.Generic;
using System.Text;

namespace RearEndCollision
{
	public enum CommandType
	{
		Idle,
		GoUp,
		GoRight,
		GoDown,
		GoLeft
	}
}
